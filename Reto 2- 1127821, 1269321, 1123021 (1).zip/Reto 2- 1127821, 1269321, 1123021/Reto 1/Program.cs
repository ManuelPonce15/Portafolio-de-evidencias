﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Reto_2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Random r = new Random();
            int a = r.Next(1,101);
            int n;

            do
            {
                Console.WriteLine("Ingrese un número: ");
                n=Convert.ToInt32(Console.ReadLine());

                if(n> a)
                {
                    Console.WriteLine("El número es menor que "+ n);
                }
                
                if (n < a)
                {
                    Console.WriteLine("El número es mayor que " + n);
                }

            }
            while (n != a);

            if (n==a)
            {
                Console.WriteLine("Adivinaste!");
            }
            Console.ReadKey();
            

        }
    }
}
