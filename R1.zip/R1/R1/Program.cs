﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace R1
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Reto No.1- 1127821, 1269321,1123021");
            int[] personas = new int[5];
            int suma = 0;


            for (int c = 0; c < 5; c++)
            {
                Console.WriteLine("Nivel " + (c + 1));
                Console.WriteLine("Ingrese la cantidad de personas que hay: ");
                personas[c] = Convert.ToInt32(Console.ReadLine());
            }

            int posicion = Array.IndexOf(personas, personas.Max());
            
            Console.WriteLine("El nivel con mas personas es: " + (posicion + 1));

          
            
            Console.WriteLine("El total de personas en el edificio es de:" + personas.Sum());

            for (int c = 0; c < 5; c++)
            {
                Console.WriteLine("Nivel " + (c + 1));
                Console.WriteLine("La cantidad de personas que hay es:" + personas[c]);
            }
            

                Console.ReadKey();
        }
    }
}

