﻿using System;

namespace reto_Semana10
{
    class Program
    {
        static void Main(string[] args)
        {
            //se declaran variables
            int dia, mes, año;
            string plan;

            //se le pide al usuario una fecha
            Console.WriteLine("Ingrese una fecha (en números)");
            Console.WriteLine("Día: ");
            dia = int.Parse(Console.ReadLine());
            Console.WriteLine("mes: ");
            mes = int.Parse(Console.ReadLine());
            Console.WriteLine("año: ");
            año = int.Parse(Console.ReadLine());

            //se pregunta si pasará ese día con su familia
            Console.WriteLine("planea pasar con su familia ese día? (si/no): ");
            plan = Console.ReadLine();

            //Se declara una variable en base al resultado retornado de la función
            bool respuesta = navidadEnFamilia(dia, mes, plan);


            if(respuesta == true)
            {
                Console.WriteLine("Pasará navidad con su familia en el año " + año);
            }
            else
            {
                Console.WriteLine("No pasará navidad con su familia en el año " + año);
            }

            Console.ReadKey();
        }

        //función que valida si se pasará navidad en familia
        static bool navidadEnFamilia(int dia, int mes, string plan)
        {
            bool resultado = false;
            if(dia == 24 && mes == 12 && plan == "si")
            {
                resultado = true;
            }
            return resultado;
        }
    }
}
