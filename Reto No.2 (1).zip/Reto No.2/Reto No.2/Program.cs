﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Reto_No._2
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Reto No.2- 1127821, 1269321,1123021");
            int[] adultos = new int[5];
            int[] niños= new int[5];
            int sumatoria = 0;

            //Cantidad de adultos y niños  que viven por nivel para luego mostrar la siguiente información:

            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("NIVEL "+(i+1));
                Console.WriteLine("Ingrese el número de adultos: ");
                adultos[i] = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Ingrese el número de niños: ");
                niños[i] = Convert.ToInt32(Console.ReadLine());

            }

            Console.WriteLine("Total de adultos en el edificio: "+adultos.Length);
            Console.WriteLine("Total de niños en el edificio: " + niños.Length);

            for (int i = 0; i < 5; i++)
            {
                sumatoria = adultos.Length+ niños.Length;
            }
            Console.WriteLine("El total de adultos y niños es " + sumatoria);

            Console.ReadKey();
        }
    }
}
