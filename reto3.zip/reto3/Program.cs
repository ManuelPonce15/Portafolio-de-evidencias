﻿using System;

namespace reto3
{
    class Program
    {
        public static double calcularprecio(string tipohelado, int topping)
        {
            double precio = 0;
            if (tipohelado == "Chocolate" || tipohelado == "Vainilla" || tipohelado == "Fresa")
            {
                precio = 5;
            }
            else if (tipohelado == "Napolitano" || tipohelado == "Pistacho")
            {
                precio = 7;
            }
            switch (topping)
            {
                case 1: // cobertura de chocolate 
                    precio = precio + 1;
                    break;
                case 2: // cobertura de chocolate con manias
                    precio = precio + 2;
                    break;
                case 3: // cobertura de chocolate con anicillos 
                    precio = precio + 1;
                    break;
            }
            return precio;
        }
        public static void Main(string[] args ) { }
    }
}
 
