﻿using System;

namespace L10_MAPJ_1127821 
{
    class Program
    {
        static void Main(string[] args)
        {
            string user = "";
            string password = "";
            int cont = 1;


            while (cont <= 3)
            {
                Console.WriteLine("Login: intento# " + cont);
                Console.WriteLine("\nIngrese Usuario");
                user = Console.ReadLine();
                Console.WriteLine("Ingrese Contraseña");
                password = Console.ReadLine();

                if (Login(user, password) == false)
                {
                    cont++;
                    Console.WriteLine("\n Usuario y/o contraseña incorrectos");
                    Console.ReadLine();
                    Console.Clear();
                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("Bienvenido!");
                    Console.ReadLine();
                    Environment.Exit(0);
                }


            }

            Console.WriteLine("Se llego al numero de intentos permitidos, intente mas tarde");
            Console.ReadLine();

        }

        public static bool Login(string user, string password)
        {
            if ((user == "usuario1") && (password == "asdasd"))
            {
                return true;
            }
            return false;
        }

    }
}
