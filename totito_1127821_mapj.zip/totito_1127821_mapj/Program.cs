﻿using System;

namespace totito_1127821
{
    class program
    {
        public static string[,] tablero = new string[3, 3];
        //jugador 1 = x
        //jugador 2 = o
        public static void jugar(int numJugador, int fila, int col)
        {
            string pieza = "";
            if (numJugador == 1)
            {
                pieza = "x";
            }
            else
            {
                pieza = "o";
            }
            if (tablero[fila, col] == "")
            {
                tablero[fila, col] = pieza;
            }
            else
            {
                Console.WriteLine("Posicion ya esta ocupada");
            }
        }
        //mostrar tablero 
        public static void mostrartablero()
        {
            for (int f = 0; f < 3; f++)
            {
                for (int c = 0; c < 3; c++)
                {
                    Console.Write(tablero[f, c] + "|");
                }
                Console.WriteLine();
            }
        }
        // iniciar el tablero
        public static void iniciartablero()
        {
            for (int f = 0; f < 3; f++)
            {
                for (int c = 0; c < 3; c++)
                {
                    tablero[f, c] = "";
                }
                Console.WriteLine();
            }
        }
        //si devuelve 1 o 2 es el jugador si devuelve 0 nadie gano
        public static int evaluar()
        {
            for (int f = 0; f < 3; f++)
            {
                if (tablero[f, 0] == tablero[f, 1] && tablero[f, 1] == tablero[f, 2]) 
                {
                    if (tablero[f, 0] == "x")
                    {
                        return 1;
                    }
                    else
                    {
                        return 2;
                    }
                }

            }

            return 0;
        }


        public static void Main()
        {
            iniciartablero();
            jugar(1, 0, 0);
            mostrartablero();
            jugar(2, 1, 1);
            jugar(1, 0, 1);
            jugar(2, 1, 2);
            jugar(1, 0, 2);
            mostrartablero();
        }
    }
}



