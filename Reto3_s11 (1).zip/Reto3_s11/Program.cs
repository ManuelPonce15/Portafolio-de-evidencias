﻿using System;
using System.Linq;

namespace Reto3_s11
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] adultos = new int[5], niños = new int[5];
            string[] responsable = new string[5];

            for(int i = 0; i < 5; i++)
            {
                Console.WriteLine("Nivel " + (i + 1));
                Console.Write("Número de adultos: ");
                adultos[i] = int.Parse(Console.ReadLine());

                Console.Write("Número de niños: ");
                niños[i] = int.Parse(Console.ReadLine());

                Console.Write("Nombre del responsable: ");
                responsable[i] = Console.ReadLine();
            }
            Console.WriteLine();

            for (int i = 0; i < 5; i++)
            {
                Console.WriteLine("Nivel " + (i + 1));
                Console.WriteLine("Cantidad de adultos: " + adultos[i]);
                Console.WriteLine("Cantidad de niños: " + niños[i]);
                Console.WriteLine("Responsable: " + responsable[i]);
            }

            int posicion = Array.IndexOf(niños, niños.Max());

            Console.WriteLine("El nombre del responsable del nivel con más niños es: " + responsable[posicion]);

        }
    }
}
